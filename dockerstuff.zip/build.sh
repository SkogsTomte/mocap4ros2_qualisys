sudo docker build -t ros2qtm_img . 

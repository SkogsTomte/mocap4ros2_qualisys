xhost +
sudo docker run -it --env="DISPLAY" --net=host --rm --privileged -v /dev/bus/usb:/dev/bus/usb ros2qtm_img bash
